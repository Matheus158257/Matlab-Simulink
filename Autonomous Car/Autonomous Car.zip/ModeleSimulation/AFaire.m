A faire : 

1) Calculer la vitesse lat�rale � partir des dx/dt et dy/dt
2) V�rifier les unit�s et signe de Yaw_rate et Yawrate "LatVel"
3) Dans la commande : v�rifier les unit�s
4) Corriger dans le bloc de g�n�ration trajectoire l'unit� du Traj.Heading (carto): il faut la passer en rd
5) La connection entre le bloc g�n�ration de trajectoire et commande : confusion entre "cap v�hicule de r�f�rence" et "cap r�f�renc� au Nord"
6) Cr�er des mod�les de bruits enregistr�s � partir de mesures et les r�injecter dans la commande
7) Filtrer les signaux si n�cessaire