clear all
close all;
clc;

%% Link with chanel definition
% https://racelogic.support/01VBOX_Automotive/01General_Information/Knowledge_Base/Channel_Definitions

% Load trajectory
load Trajectoire_ChoukiLQR1_003;
if Traj.Version~=7
    error('pb version traj');
end

% Pilotage tps r�el du v�hicule : suivi de trajectoire
Te=10e-3;

% Lambert projection stuff
Lambert93=InitLamber93;

% Chargement du v�hicule
cd Vehicle;
Display.Vehicle=0;
Vehicle=C1_Vehicle(Display);
cd ..

% Lateral control parameters
cd control;
Control=AutonomousVehicleControl(Vehicle);
cd ..



% Display trajectory
% figure;
% plot(Traj.X,Traj.Y);
% grid on;
% 
% figure;
% plot(Traj.Lat,Traj.Long,'r');
% grid on;

% Setup initial parameter
InitialCondition=SetInitialCondition(Vehicle,Traj,Lambert93);


% Lauch simulation
SimResult=sim('ModeleVehicule2017_LongLateral',100);

if 1==0
    xvar=SimResult.tsim;
    xlab='time (s)';
else
    xvar=SimResult.dist;
    xlab='distance (m)';
end
figure;
plot(xvar,SimResult.Cmd_Vmax,'r');
hold on
plot(xvar,SimResult.Cmd_Velocity_SP,'b');
plot(xvar,SimResult.Vehicle_speed*3.6,'g');
grid on
xlabel(xlab);
legend('Vmax Interdst','Velocity setpoint','Vehicle Speed')
% Affichage de r�sultat de simulation
% figure;
% plot(Traj.X,Traj.Y,'r');
% hold on;
% plot(SimResult.Xlocal,SimResult.Ylocal,'b');
% grid on;

figure;
subplot(3,1,1);
plot(xvar,SimResult.Cmd_Velocity_SP,'r');
hold on;
plot(xvar,SimResult.Vehicle_speed*3.6,'b');
grid on;
legend('Velocity SP km/h','actual');
xlabel(xlab);

subplot(3,1,2);
plot(xvar,SimResult.Cmd_Brake_Pedal_Pos_SP,'r');
hold on;
plot(xvar,SimResult.BRAKE_pedal_pos,'b');
grid on;
legend('Pedal Pos Setpoint','Actual Pos');
xlabel(xlab);

subplot(3,1,3);
plot(xvar,SimResult.Cmd_ICE_Throttle,'r');
grid on;
legend('ICE Throttle');
xlabel(xlab);
