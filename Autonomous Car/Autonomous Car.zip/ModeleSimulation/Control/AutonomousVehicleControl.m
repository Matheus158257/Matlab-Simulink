function Control=AutonomousVehicleControl(Vehicle)
% Control.fc=Vehicle.fc; % Send the IC engine data to the controller


DelaysBrakePedal = 0;
DelaysBrakeVelocity = 0;
Te = 0.01;

Control.Vehicle=Vehicle;
Control.PedalPosition=BrakePedalControl(Vehicle,Te,DelaysBrakePedal);
Control.BrakeControl=VelocityBrakeControl(Vehicle,Te,DelaysBrakeVelocity,Control.PedalPosition);
Control.ThrottleControl=VelocityThrottleControl(Vehicle,Te);
Control.LateralPurePursuit=ParametresGuidageLateral;
Control.LateralLQR=CommandeLineaireLQR_Choucki(Vehicle);
