function Control=AutonomousVehicleControl(Vehicle)
Control.fc=Vehicle.fc; % Send the IC engine data to the controller


DelaysBrake = 0;
Te = 0.01;
p = tf('p');
z = tf('z', Te, 'variable', 'z^-1');
%__________________________Brake Controller________________________________
%{
Control.a1_B = 0.2053;
Control.b1_B = 0.0022;
Control.a2_B = -254.6771;
Control.b2_B = 272.5; % Force = 0 -> Pedal Pos = 750
% Master Cylinder Pressure VS. Pedal Position
        % Y = a1*exp(b1*X);
% Brake Force VS. Master Cylinder Pressure
        % Y = a2*X + b2;
% Pedal Position VS. Master Cylinder Pressure
        % X = log(Y/a1) / b1;
% Master Cylinder Pressure VS. Brake Force
        % X = (1/a2)*Y - b2/a2;
%}
% Car Model Parameters
Vo = 20;
Body = C1_Body;
% Pedal Dynamics Parameters
K = 225;
Tau1 = 0.1;
Tau2 = 2.1;
Ks = 0.00125;
    % Pedal Dynamics--------------------------------
    F = (K*exp(-DelaysBrake*0.01*p)) / (Tau1*Tau2*p*p + (Tau1+Tau2)*p + Ks);
    %F = K / (Tau1*Tau2*p*p + (Tau1+Tau2)*p + Ks);
    Fboz = c2d(F, Te, 'zoh');
    Fboz = absorbDelay(Fboz);
    Fboz = set(Fboz, 'variable', 'z^-1');
    % Prespecification
    Hs = 1;
    Hr = 1;
    % Dynamique de la boucle ferm�e
    Gpedal = 1/(1+0.1*p)^2;
    [R,S,T,info,A,B] = CalculeRST2(Fboz, Hr, Hs, Gpedal);
    Control.Spz_P = minreal( S / Hs);
    Control.Rpz_P = minreal( R / Hr);
    Control.Sz_P = S;
    Control.Rz_P = R;
    Control.T_P = T;
    Control.F_P = F;
    Control.Tau1_P = Tau1;
    Control.Tau2_P = Tau2;
    Control.K_P = K;
    Control.Ks_P = Ks;
    Control.Umax_P = 100;
    Control.Umin_P = -100;
    Fboz1 = info.Sycy;
  
F = exp(-DelaysBrake*0.01*p) / (p*Body.Mass + Body.rho_air*Body.Sf*Body.Cd*Vo)
%F = 1 / (p*Body.Mass + Body.rho_air*Body.Sf*Body.Cd*Vo);    
Fboz = c2d(F, Te, 'zoh')
Fboz = absorbDelay(Fboz)
Fboz = set(Fboz, 'variable', 'z^-1');
Fboz = Fboz * Fboz1;

% Prespecification
Hs = 1 - z^-1;
Hr = 1;
% Dynamique de la boucle ferm�e
G = 1/(1+0.35*p)^2/(1+0.1*p)^2;
%G = 1/(1+0.3*p)^2;
[R,S,T,info,A,B] = CalculeRST2(Fboz, Hr, Hs, G);

Control.G = G;
Control.Spz_B = minreal( S / Hs);
Control.Rpz_B = minreal( R / Hr);
Control.Rz_B = R;
Control.Sz_B = S;
Control.T_B = T;
Control.F_B = F;
Control.Umax_B = 0;
Control.Umin_B = -4000;
%------------------------END Brake Controller------------------------------



%__________________________Motor Controller________________________________
% Car Model Parameters
Vo = 20;
Body = C1_Body;

F = (1)/(p*Body.Mass + Body.rho_air*Body.Sf*Body.Cd*Vo);    
Fboz = c2d(F, Te, 'zoh');
Fboz = set(Fboz, 'variable', 'z^-1');
% Prespecification
Hs = 1 - z^-1;
Hr = 1;
% Dynamique de la boucle ferm�e
G = 1/(1+1.2*p)^2;
[R,S,T,info,A,B] = CalculeRST2(Fboz, Hr, Hs, G);

Control.Spz_M = S / Hs;
Control.Rpz_M = R / Hr;
Control.Rz_M = R;
Control.Sz_M = S;
Control.T_M = T;
Control.F_M = F;
Control.Umax_M = 100;
Control.Umin_M = 0;
%------------------------END Motor Controller------------------------------












