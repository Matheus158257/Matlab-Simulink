function PedalPosition=BrakePedalControl(Vehicle,Te,DelaysBrakePedal)
p = tf('p');
z = tf('z', Te, 'variable', 'z^-1');

%__________________________Brake Controller________________________________
% Force -> Pedal Position -> Force converstion
% We will compute the values for the lookup table


% Car Model Parameters
Vo = 20;

Fboz=c2d(Vehicle.Brake.PedalDynamics,Te,'zoh');
Fboz = set(Fboz, 'variable', 'z^-1');
% Prespecification
Hs = 1-z^-1;
Hr = 1;

% Dynamique de la boucle ferm�e
Gpedal = 1/(1+0.1*p)^2;
[R,S,T,info,A,B] = CalculeRST2(Fboz, Hr, Hs, Gpedal);
PedalPosition.Spz_P = minreal( S / Hs);
PedalPosition.Rpz_P = minreal( R / Hr);
PedalPosition.Sz_P = S;
PedalPosition.Rz_P = R;
PedalPosition.T_P = T;
PedalPosition.F_P = Vehicle.Brake.PedalDynamics;

PedalPosition.Umax_P = 100;
PedalPosition.Umin_P = -100;
PedalPosition.Sycy= info.Sycy;

PedalPosition.Force_P2F=Vehicle.Brake.Force_P2F;
PedalPosition.Pedal_P2F=Vehicle.Brake.Pedal_P2F;
PedalPosition.Force_F2P=Vehicle.Brake.Force_F2P;
PedalPosition.Pedal_F2P=Vehicle.Brake.Pedal_F2P;

