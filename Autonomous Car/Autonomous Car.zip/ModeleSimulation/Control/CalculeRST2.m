function [R,S,T,info,A,B]=CalculeRST2(Fboz,Hr,Hs,G)
% Calcule un correcteur RST avec pr�sp�cification Hr,Hs
% la dynamique souhait�e est donn�es dans G
% info renvoie les infos sur les ordres des polynomes
if isct(Fboz)
    error('F must be discrete');
end;
Te=get(Fboz,'Ts');
z=tf('z',Te);
set(z,'variable','z^-1')

if isempty(Hr)
    Hr=1;
end;
if isempty(Hs)
    Hs=1;
end;

if ~isstable(G)
    warning('G is not stable');
end;
if ~isnumeric(Hs)&&~isstable(Hs)
    warning('Hs is not stable');
end;
if ~isnumeric(Hr)&&~isstable(Hr)
    warning('Hr is not stable');
end;
[bp,ap]=tfdata(Fboz*Hr/Hs,'v');
% Enleve les z�ros inutiles a la fin des polynomes
i=length(ap);
ended=ap(i)~=0;
while ended==0
    i=i-1;
    if i<0
        error('tous les coef de A'' sont � z�ro');
    end;
    ended=ap(i)~=0;
end
ap=ap(1:i);

% Enleve les coefs inutiles a la fin des polynomes
i=length(bp);
ended=bp(i)~=0;
while ended==0
    i=i-1;
    if i<0
        error('tous les coef de B'' sont � z�ro');
    end;
    ended=bp(i)~=0;
end
bp=bp(1:i);

nbp=length(bp)-1;
nap=length(ap)-1;
Ap=0;
for i=1:nap+1
    Ap=Ap+ap(i)*z^-(i-1);
end;
Bp=0;
for i=1:nbp+1
    Bp=Bp+bp(i)*z^-(i-1);
end;
nrp=nap-1;
nsp=nbp-1;
M2=zeros(nrp+nsp+2,nrp+nsp+2);
for i=1:nsp+1
    M2(i:i+nap,i)=ap';
end
for i=1:nrp+1
    M2(i:i+nbp,i+nsp+1)=bp';
end;

if isct(G)
    % Mod�le continu => il faut l'�chantillonner avec un bloqueur
    Gz=c2d(G,Te,'zoh');
else
    % Mod�le discret
    Gz=G;
end
[~,Pbut]=tfdata(Gz,'v');
Pbut(end+1:nrp+nsp+2)=0;
Pbut=Pbut';
if length(Pbut)>nrp+nsp+2
    error(sprintf('G must be of an order lower than %i\n',nrp+nsp+1));
end;
Phi=M2\Pbut;
sp=Phi(1:nsp+1);
rp=Phi(nsp+2:end);

% Constitution des polynomes R et S
Sp=0;
for i=1:nsp+1
    Sp=Sp+sp(i)*z^-(i-1);
end;
S=Sp*Hs;
Rp=0;
for i=1:nrp+1
    Rp=Rp+rp(i)*z^-(i-1);
end;
R=Rp*Hr;

[b,a]=tfdata(Fboz,'v');
T=sum(Pbut)/sum(b)+0*z^-1;
info.Te=Te;
info.ns=nsp;
info.nr=nrp;

[b,a]=tfdata(Fboz,'v');
nb=length(b)-1;
na=length(a)-1;
A=0;
for i=1:na+1
    A=A+a(i)*z^-(i-1);
end;
B=0;
for i=1:nb+1
    B=B+b(i)*z^-(i-1);
end;
set(A,'variable','z^-1')
set(B,'variable','z^-1')
info.Sbu=-A*R/(A*S+B*R);
info.Sycy=T*B/(A*S+B*R);
info.Sdyy=A*S/(A*S+B*R);
info.Sduy=B*S/(A*S+B*R);
info.Sby=-B*R/(A*S+B*R);
info.Sycu=T*A/(A*S+B*R);
info.Sdyu=-A*R/(A*S+B*R);
info.Sbu=-B*R/(A*S+B*R);
info.Fboz=B/A;

info.npmax=nrp+nsp+1;
info.StableRST=isstable(Rp/Sp);

if (info.StableRST==0)
  warning('RST is not internaly stable');
end;


% Marge de module
[mag1,phase1,w] = bode(info.Sdyy);
[mag1,phase1,w1] = bode(info.Sdyy,logspace(log10(min(w)),log10(max(w)),1000));
mag1dB=20*log10(squeeze(mag1));
info.MargeModuledB=-max(mag1dB);
info.MargeModule=10^(info.MargeModuledB/20);
[Gm,Pm,Wgm,Wpm] = margin(Fboz*R/S); 

info.MargeDeGain=Gm;
info.MargeDeGaindB=20*log10(Gm);
info.MargeDePhase=Pm;

info.M=M2;
info.Pbut=Pbut;