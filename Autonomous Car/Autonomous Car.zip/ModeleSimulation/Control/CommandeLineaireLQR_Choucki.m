function Control=CommandeLineaireLQR_Choucki(Vehicle)

% Sampling time
Ts=0.01;


% Input constraints
umax = 10*16*pi/180; % 10 deg

v= 15 ; % velocity in m/s
%% State constarints
rmax = 0.55;  %in rad/s  (aymax = vmax*rmax)
ylmax = 1;   % in m
Psilmx = 0.1;  %in rad/s


%% Q & R matrix design constants
R_des = 0.1;   % Rmatrix

beta_q = 0 ;  % weighting for beta

r_q = 10 ; % weighting for ay

psil_q = 10; %wighting for psil

yl_q = 10 ; %wighting for yl




%% Model parameters                                Value
mu=1;                    % Pour le calcul du mod�le lin�aire nominal, utilisation de mu                 (Mis � jour)
Cyav = 57000;             % raideurs lat�rales des pneumatiques avant                                   (Mis � jour)
Cyar = 59000;             % raideurs lat�rales des pneumatiques arri�re                                 (Mis � jour)
cf0 = Cyav*mu;
cr0 = Cyar*mu;
Cf = cf0;
Cr = cr0;
% Lf, distance form CG to frontaxle                1.0065m
Lf= 1.08; %1.3;
% Lr, distance from CG to rearaxle                 1.4625m
Lr= 1.24;  %1.6;
% Action of wind !!!!
Lw=0.4;
% Lookahead distance
Ls=  5;     % 6.6; % Distance de vis�e du conducteur en m
M=  1077; %      2024.86;                   % Masse globale du v�hicule                                                (Mis � jour)

% Iz, vehicle yaw moment of inertia                 2454 kgm�
Iz=  Lf*Lr*M;         %2800;

% n_t , tire length contact                        0.13m
n_t=0.13;

%% LTI system
e12=1/(M*v);
    e22=Lw/Iz;
    a11=-2*(cf0+cr0)/(M*v);
    a12=-1+2*(Lr*cr0-Lf*cf0)/(M*v^2);
    a21=2*(Lr*cr0-Lf*cf0)/Iz;
    a22=-2*(Lr^2*cr0+Lf^2*cf0)/(Iz*v);

    b1=2*cf0/(M*v);
    b2=2*(cf0*Lf)/Iz;
 % Etat=[beta; r; PsiL; Yl]
    A=[a11 a12  0  0;
       a21 a22  0  0;
         0   1  0  0;
         v  Ls  v  0];

%u=[deltaf;
    %   fw;
    %   roref ]; 
    Bu=[b1;
        b2;
        0;
        0];

    Bw1=[e12;
         e22;
         0;
         0];

    Bw2=[0;
         0;
        -v;
         0];
 
    B=[Bu,Bw1,Bw2];
  C=[ 1   0    0    0;
        0   1    0    0;
        0   0    1    0;
        0   0    0    1];
   D =        [0   0   0;
                0   0   0;
                0   0   0;
                0   0   0];
  z=  [0 v 0 0; 0 0 1 0; 0 0 0 1];          
            

%% LQR Controller gains

Rr = R_des;

Qr = diag ([beta_q;r_q;psil_q;yl_q]);

Kc_LQR = lqr(A,Bu(:,1),Qr,Rr);  

eig(A-Bu(:,1)*Kc_LQR)


Control.Kc_LQR=Kc_LQR;