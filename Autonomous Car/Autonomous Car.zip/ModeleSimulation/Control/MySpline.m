function [s1, s2] = MySpline(x, y, Midpoint)

x = [x(1), x(Midpoint), x(end)];
y = [y(1), y(Midpoint), y(end)];

colorCurve = 'r';
colorPoint = 'k'; % 'colorPoint = None' no Points

NumT = 50;
n = length(x);
h = zeros(1,n-1);
for i = 1:n-1
   h(i) = x(i+1) - x(i);
end
h;
H = zeros(n,n);
H(1, 1) = 1;
for i = 1:n-2
   H(i+1, i) = h(i);
   H(i+1, i+1) = 2*(h(i)+h(i+1));
   H(i+1, i+2) = h(i+1);   
end
H(n, n) = 1;
H;

Ah = zeros(n,1);
Ah(1) = 0;
for i = 1:n-2
   Ah(i+1) = 3*((y(i+2)-y(i+1))/h(i+1) - (y(i+1)-y(i))/h(i));
end
Ah(n) = 0;
invH = inv(H);
c = H\Ah;

a = y';

b = zeros(1, n-1);
for i = 1:n-1
    b(i) = (a(i+1) - a(i))/h(i) - (h(i)/3)*(2*c(i)+c(i+1));
end
b = b';

d = zeros(1, n-1);
for i = 1:n-1
    d(i) = (c(i+1)-c(i))/(3*h(i));
end
d = d';

s1 = [a(1), b(1), c(1), d(1)];
s2 = [a(2), b(2), c(2), d(2)];



end