function Commande=ParametresGuidageLateral
% Calibration angle volant
% Donn�e de r�gression issues du Plp 2016
Commande.CoefVolantB=-1.65388e+00;
Commande.CoefVolantA=-6.01550e-02;

% Param�tres g�om�triques du v�hicule
Commande.lf = 1.08;
Commande.lr = 1.24;
Commande.Long=3.34;
Commande.Larg=2;

% Offset sur le cap mesur�
% + 90� : la centrale inertielle renvoie 0� au nord au lieu de 90�
% + 3.61� : d�faut d'alignement de la centrale inertielle avec l'axe
% longitudinal du v�hicule
Commande.OffsetPsiCentraleInertielle=90+3.61;


