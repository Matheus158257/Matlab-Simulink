function BrakeControl=VelocityBrakeControl(Vehicle,Te,DelaysBrakeVelocity,PedalPosition)
%  Compute a brake controller for the autonomous car

p = tf('p');
z = tf('z', Te, 'variable', 'z^-1');

F = 1 / (1+0.1*p)^3;
Filter = c2d(F, Te, 'zoh');
Filter = set(Filter,'variable','z^-1');

%D=exp(-Te/0.1);
%Filter = (1-D)^3/(z-D)^3;
%__________________________Motor Controller________________________________
BrakeControl=cell(Vehicle.Gearbox.NbGears+1,1);

VoGear=[10 25 25 75 100 125]/3.6; % [Neutral, 1, 2, 3, 4, 5]
TauGear=[0.5 0.3 0.3 0.3 0.3  0.3]; % [Neutral, 1, 2, 3, 4, 5]
for NoGear=1:Vehicle.Gearbox.NbGears+1
    BrakeControl{NoGear}.Umax = 0;
    BrakeControl{NoGear}.Umin = -4000;    
    % Linearization point     
    if NoGear == 6 % Neutral Controller is the sixth controller
        Vo=VoGear(1);
        Tau=TauGear(1);
        Rk=Vehicle.Gearbox.Ratio(1)*Vehicle.FinalDrive.Ratio;
    else
        Vo=VoGear(NoGear+1);
        Tau=TauGear(NoGear+1);
        Rk=Vehicle.Gearbox.Ratio(NoGear+1)*Vehicle.FinalDrive.Ratio;
    end
    % Car Model Parameters
    EquivalentMass= Vehicle.Mass+Vehicle.fc.inertia*Rk^2/Vehicle.Tire.Radius^2;
    F = 1/(p*EquivalentMass + Vehicle.rho_air*Vehicle.Sf*Vehicle.Cd*Vo);
    %[zz,pp,kk]=zpkdata(F,'v');
%     zpk(F)
    % Pedal Model Dynamics
    Fboz = c2d(F, Te, 'zoh');
    Fboz=set(Fboz,'variable','z^-1');
    %Fboz = Fboz*PedalPosition.Sycy;
    
    % Prespecification
    Hs = 1 - z^-1;
    Hr = 1;
    
    % Dynamique de la boucle ferm�e
    %G = 1/(1+Tau*p)^2/(1+Tau/2*p)^5;
    G = 1/(1+Tau*p)^2;%/(1+0.1*p)^2;
    [R,S,T,info,A,B] = CalculeRST2(Fboz, Hr, Hs, G);
    
%     figure;bode(info.Sdyy);grid on;title('dy y ''Output''');
%     figure;bode(info.Sdyu);grid on;title('dy u ''Input''');
%     figure;bode(info.Sbu);grid on;title('b u ''Noise''')
%     figure;bode(info.Fboz);grid on;title('b/a ''System''')
%     figure;bode(PedalPosition.Sdyy);grid on;title('P  dy y ''Output''');
%     figure;bode(PedalPosition.Sdyu);grid on;title('P  dy u ''Input''');
%     figure;bode(PedalPosition.Sbu);grid on;title('P  b u ''Noise''');
%     figure;bode(PedalPosition.Fboz);grid on;title('P  b/a ''System''');
% 
%     error5
    BrakeControl{NoGear}.G_B = G;
    BrakeControl{NoGear}.Spz_B = minreal( S / Hs);
    BrakeControl{NoGear}.Rpz_B = minreal( R / Hr);
    BrakeControl{NoGear}.Rz_B = R;
    BrakeControl{NoGear}.Sz_B = S;
    BrakeControl{NoGear}.T_B = T;%*Filter;
    BrakeControl{NoGear}.F_B = F;
    BrakeControl{NoGear}.dyy = info.Sdyy;
    BrakeControl{NoGear}.bu = info.Sbu;
    BrakeControl{NoGear}.duy = info.Sduy;
    BrakeControl{NoGear}.Feedforward.Meq=EquivalentMass;
    BrakeControl{NoGear}.Feedforward.a=Vehicle.Mass*9.81*Vehicle.Tire.c0;
    BrakeControl{NoGear}.Feedforward.b=0.5*Vehicle.rho_air*Vehicle.Sf*Vehicle.Cd;

end;
