function ThrottleControl=VelocityThrottleControl(Vehicle,Te)

p = tf('p');
z = tf('z', Te, 'variable', 'z^-1');

%__________________________Motor Controller________________________________
ThrottleControl=cell(Vehicle.Gearbox.NbGears+1,1);
% Open loop controller at the start 0->1 m/s
D=exp(-Te/0.25);
ThrottleControl{6}.TFopen = 3000*(1-D)^2/(z-D)^2;

VoGear=[30 60 90 110 130]/3.6;
TauGear   =[0.5 0.5 0.4 0.3 0.3];
for NoGear=1:Vehicle.Gearbox.NbGears
    % Linearization point
    Vo=VoGear(NoGear);
    Rk=Vehicle.Gearbox.Ratio(NoGear+1)*Vehicle.FinalDrive.Ratio;
    % Car Model Parameters
    EquivalentMass= Vehicle.Mass+Vehicle.fc.inertia*Rk^2/Vehicle.Tire.Radius^2;
    F = 1/(p*EquivalentMass + Vehicle.rho_air*Vehicle.Sf*Vehicle.Cd*Vo);
    % ICE Model Dynamics
    Fice = 1/(1+p*0.3);    
    Fboz = c2d(F*Fice, Te, 'zoh');
    Fboz=set(Fboz,'variable','z^-1');
    
    % Prespecification
    Hs = 1 - z^-1;
    Hr = (1+0.5*z^-1);
    %Hr=1;
    
    % Dynamique de la boucle ferm�e
    Tau1=TauGear(NoGear);
    Tau2=TauGear(NoGear)/2;
    
    G = 1/(1+Tau1*p)^2/(1+Tau2*p)^2;
    [R,S,T,info,A,B] = CalculeRST2(Fboz, Hr, Hs, G);
    
    ThrottleControl{NoGear}.G_M = G;
    ThrottleControl{NoGear}.Spz_M = minreal( S / Hs);
    ThrottleControl{NoGear}.Rpz_M = minreal( R / Hr);
    ThrottleControl{NoGear}.Rz_M = R;
    ThrottleControl{NoGear}.Sz_M = S;
    ThrottleControl{NoGear}.T_M = T;
    ThrottleControl{NoGear}.F_M = F;
    ThrottleControl{NoGear}.dyy = info.Sdyy;
    ThrottleControl{NoGear}.bu = info.Sbu;
    ThrottleControl{NoGear}.duy = info.Sduy;
    ThrottleControl{NoGear}.Feedforward.Meq=EquivalentMass;
    ThrottleControl{NoGear}.Feedforward.a=Vehicle.Mass*9.81*Vehicle.Tire.c0;
    ThrottleControl{NoGear}.Feedforward.b=0.5*Vehicle.rho_air*Vehicle.Sf*Vehicle.Cd;
%     if NoGear==2
%         figure(10);
%         bode(info.Sbu);
%         hold on;
%         grid on;
%         title('Noise to control');
%         
%         figure(11);
%         pzmap(R/S);grid on;
%         error('stop');
%     end;
end;
% Clutch things:
% 1.104 fully closed
% 1.5 slipping
% 2 open
CthMax=max(Vehicle.fc.max_trq)*1.1;
ThrottleControl{1}.TabClutch=[0 1.104 1.5 2 3 ];
ThrottleControl{1}.MaxThrottle=[110 110 10 5 5];