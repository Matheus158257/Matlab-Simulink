function InitialCondition=SetInitialCondition(Vehicle,Traj,Lambert93)

% Origin of X-Y frame according to Lamber 93 parameters
% psi_init : 0 toward East (so in the direction of X axis)


% Chose Xinit and Yinit on the begining of the trajectory
[InitialCondition.Xinit,InitialCondition.Yinit]=ProjLambert(abs(Traj.Long(1))*pi/180,abs(Traj.Lat(1))*pi/180,Lambert93);
InitialCondition.psi_init=(90-Traj.Heading(1))*pi/180; % rd Zero pointing East CCW
InitialCondition.EngagedGear=1;