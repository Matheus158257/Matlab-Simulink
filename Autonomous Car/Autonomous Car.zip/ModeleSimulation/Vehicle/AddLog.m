function AddLog(hLog,Text)
global hlog
if ~iscell(Text)
    Text2{1}=Text;
    Text=Text2;
end;
for i=1:length(Text)
    hLog{end+1}=Text{i};
    fprintf('%s\n',Text{i});
end;

% Rajout dans le fichier
fich=fopen('log.txt','a');
if fich~=-1
    for i=1:length(Text)
        fprintf(fich,[Text{i} '\n \r']);
    end;
end;
fclose(fich);
