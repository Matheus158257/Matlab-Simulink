function ACC=C1_ACC
ACC.TauRef=0.1; % Time constant for auxiliary pole
ACC.wn=10;
ACC.xi=1;
ACC.SpeedTolerance=0.5/3.6;
ACC.PowerMinRegen=-12e3;
ACC.RegenTorqueRate=-50/1;