function Vehicle=C1_Body
Vehicle.Cd=0.32;
Vehicle.Sf=0.633/0.32 ;
Vehicle.g=9.81;
Vehicle.rho_air=1.225;              % Densit� de l'air (kg/m3)
Vehicle.Mass=303+329+202+243; % Poids � vide : 835, poids total en charge 1190kg

% Masse v�hicule. Pes� le 16/05/2017
% Conducteur : 73kg, Passenger : 85kg
%avant droit   : 303
%avant gauche  : 329 
%arriere droit : 202
%arrier gauche : 243
