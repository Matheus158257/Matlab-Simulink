function Brake=C1_Brake

p = tf('p');

%__________________________Brake Controller________________________________
% Force -> Pedal Position -> Force converstion
% We will compute the values for the lookup table

% Must use MySpline() function
NewPointPedal = (1.0e+03)*[0.750000000000000, 1.026916967509025,...
    1.223798561151079, 1.425750000000000, 1.588389743589744,...
    1.850000000000000, 1.981193877551021, 2.169600000000000,...
    2.356188679245283, 2.526650000000000, 2.629542857142857];
NewPointForce = (1.0e+03)*[0, 0.040483170382914, -0.231568542799422,...
    -0.489417556200801, -0.931379714190183, -2.000000000000000,...
    -2.883381687825112, -3.893552309063812, -5.444983577928459,...
    -7.147525811991742, -8.185046673520457];

% Calculate lookup table
StepSize = 1;   % Step size of Pedal Position for lookup table
Midpoint = 6;
P1 = 750:StepSize:NewPointPedal(Midpoint);
P2 = P1(end)+StepSize:StepSize:NewPointPedal(end)+StepSize;
[C1, C2] = MySpline(NewPointPedal, NewPointForce, Midpoint);
s1 = C1(1) + C1(2)*(P1 - NewPointPedal(1)) + C1(3)*(P1 - NewPointPedal(1)).^2 + C1(4)*(P1 - NewPointPedal(1)).^3;
s2 = C2(1) + C2(2)*(P2 - NewPointPedal(Midpoint)) + C2(3)*(P2 - NewPointPedal(Midpoint)).^2 + C2(4)*(P2 - NewPointPedal(Midpoint)).^3;


% Vectors used in lookup tables
Brake.Pedal_P2F = [745, P1,P2];
Brake.Force_P2F = [0, s1,s2];
Brake.Pedal_F2P = fliplr([750, P1,P2]);
Brake.Force_F2P = fliplr([1, s1,s2]);

% Brake pedal dynamics
K = 120/3;
Tau1 = 0.0498;
Tau2 = 0.0498;
Ks=1;
Brake.PedalDynamics = K / (Tau1*Tau2*p*p + (Tau1+Tau2)*p + Ks);