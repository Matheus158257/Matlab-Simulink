function [GearBox,FinalDrive]=C1_Gearbox
% =======================================================================
% Indy Mk gearbox
% =======================================================================
GearBox.Ratio=[0 1/0.2821 1/0.5227 1/0.7634 1/0.9737 1/1.1765];
GearBox.NbGears=length(GearBox.Ratio)-1;
GearBox.info='C551-A';
GearBox.Efficiency=0.95;

FinalDrive.Ratio=1/0.2817*.95; % Coef 0.95 from measurement
FinalDrive.Efficiency=0.98;



% Gearbox ratio measured on the real car
GearBox.Ratio=[0 11.95 6.46 4.42 3.46  2.8665]/FinalDrive.Ratio;


FinalDrive.Info=sprintf('Final drive ratio : %.2f efficiency : %.1f %%',FinalDrive.Ratio,FinalDrive.Efficiency);


FinalDrive.Info=sprintf('Final drive ratio : %.2f',FinalDrive.Ratio);

fprintf('Gearbox ratio : %s\n   Rapports=[ ',GearBox.info);
for NoGear=1:GearBox.NbGears+1
    fprintf('%.2f ',GearBox.Ratio(NoGear));
end;
fprintf(']\n');
fprintf('%s\n',FinalDrive.Info);

