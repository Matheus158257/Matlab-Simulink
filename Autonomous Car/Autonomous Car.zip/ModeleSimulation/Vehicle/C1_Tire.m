function Tire=C1_Tire
% 155/65 R14 75 T
Tire.Radius=0.5*14*25.4/1000+155*65/100/1000; % 235R16
Tire.Radius=0.26; % Measured 16/05/2017 
Tire.c0=0.01;
Tire.Info='155 / 65 R14 75T';
Tire.Cf = 47135;
Tire.Cr = 56636;
Tire.nt =0.13; % Surface de contact Modele Dynamique Chouki
