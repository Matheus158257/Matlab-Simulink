function Vehicle=C1_Vehicle(Display)
% V�hicule C1
% Perormances (RTA)
%   + 0-100km/h : 14.0s
%   + 400m DA : 19.5 s
% Conso :
%   + NED : 4.1 l/100km

Vehicle=C1_Body;
Vehicle=C1_steering(Vehicle);
% Chargement de pneu
Vehicle.Tire=C1_Tire;
cd EngineMap
fc=C1_engine;
cd ..

Vehicle.fc=fc;
Vehicle.MaxClutchTorque=1.5*max(fc.max_trq);
[Vehicle.Gearbox,Vehicle.FinalDrive]=C1_Gearbox;

Vehicle.Brake=C1_Brake;

% R�partition av / ar
Vehicle.lf = 1.08;
Vehicle.lr = 1.24;
Vehicle.Long=3.34;
Vehicle.Larg=2;
Vehicle.Iz = Vehicle.lf*Vehicle.lr*Vehicle.Mass;

fprintf('C1\n');
fprintf('  Vehicle mass : %.1f kg Tire Radius : %.3f\n',Vehicle.Mass,Vehicle.Tire.Radius);
%return;

% =================================================================
% Affichage des performances du v�hicule
% =================================================================

Vehicle.Perfo.TabVitesse=linspace(0,max(fc.map_spd)*Vehicle.Tire.Radius/Vehicle.Gearbox.Ratio(end)/Vehicle.FinalDrive.Ratio,201);
Vehicle.Perfo.TabFres=0.5*Vehicle.rho_air*Vehicle.Sf*Vehicle.Cd.*Vehicle.Perfo.TabVitesse.^2+Vehicle.Mass*Vehicle.Tire.c0*Vehicle.g;
for NoGear=2:Vehicle.Gearbox.NbGears+1
    TabWClutchOut=Vehicle.Perfo.TabVitesse/Vehicle.Tire.Radius*Vehicle.Gearbox.Ratio(NoGear)*Vehicle.FinalDrive.Ratio;
    Vehicle.Perfo.TabWice{NoGear}=max(fc.idle_speed,TabWClutchOut);
    ii=Vehicle.Perfo.TabWice{NoGear}>max(fc.map_spd)*0.99;
    Vehicle.Perfo.TabTiceMax{NoGear}=interp1(fc.map_spd,fc.max_trq,Vehicle.Perfo.TabWice{NoGear});
    TabClutchAlpha=Vehicle.Perfo.TabWice{NoGear}./TabWClutchOut;
    TabClutchAlpha(TabWClutchOut==0)=1;
    TabClutchAlpha=min(2,TabClutchAlpha);
    
    Vehicle.Perfo.TabTclutchMax{NoGear}=Vehicle.Perfo.TabTiceMax{NoGear}.*TabClutchAlpha;
    Vehicle.Perfo.TabTclutchMax{NoGear}=min(Vehicle.Perfo.TabTclutchMax{NoGear},Vehicle.MaxClutchTorque);
    
    Vehicle.Perfo.TabTrMaxPerGear{NoGear}=Vehicle.Perfo.TabTclutchMax{NoGear}*Vehicle.Gearbox.Ratio(NoGear)*Vehicle.Gearbox.Efficiency*Vehicle.FinalDrive.Ratio*Vehicle.FinalDrive.Efficiency;
    Vehicle.Perfo.TabAccelPerGear{NoGear}=(Vehicle.Perfo.TabTrMaxPerGear{NoGear}/Vehicle.Tire.Radius-Vehicle.Perfo.TabFres)/(Vehicle.Mass+fc.inertia*(Vehicle.Gearbox.Ratio(NoGear)*Vehicle.FinalDrive.Ratio)^2/Vehicle.Tire.Radius^2);
    Vehicle.Perfo.TabTrMaxPerGear{NoGear}(ii)=NaN;
    Vehicle.Perfo.TabAccelPerGear{NoGear}(ii)=NaN;
    if (NoGear>2)
        % Patinage interdit
        ii=find(TabWClutchOut<fc.idle_speed);
        Vehicle.Perfo.TabTrMaxPerGear{NoGear}(ii)=NaN;
        Vehicle.Perfo.TabAccelPerGear{NoGear}(ii)=NaN;
    end;
end;
Vehicle.Perfo.TabAccel=Vehicle.Perfo.TabAccelPerGear{2};
Vehicle.Perfo.TabTrMax=Vehicle.Perfo.TabTrMaxPerGear{2};

Vehicle.Perfo.Gear=Vehicle.Perfo.TabVitesse*0+1;
for NoGear=3:Vehicle.Gearbox.NbGears+1
    Vehicle.Perfo.TabAccel=max(Vehicle.Perfo.TabAccelPerGear{NoGear},Vehicle.Perfo.TabAccel);
    Vehicle.Perfo.TabTrMax=max(Vehicle.Perfo.TabTrMaxPerGear{NoGear},Vehicle.Perfo.TabTrMax);
    
    ii=find(Vehicle.Perfo.TabAccel==Vehicle.Perfo.TabAccelPerGear{NoGear});
    Vehicle.Perfo.Gear(ii)=NoGear-1;
end;

if Display.Vehicle~=1
    return;
end;

Coul='rgbckmrgbckm';
Chaine='legend(';


figure;
subplot(1,2,1);
for NoGear=2:Vehicle.Gearbox.NbGears+1
    plot(Vehicle.Perfo.TabVitesse*3.6,Vehicle.Perfo.TabTrMaxPerGear{NoGear},Coul(NoGear-1));
    hold on;
    Chaine=[Chaine '''gear=' num2str(NoGear-1) ''','];
end;
xlim([0 max(Vehicle.Perfo.TabVitesse)*3.6]);
eval([Chaine(1:end-1) ');']);
grid on;
xlabel('v (km/h)');
ylabel('T_{wheel max} (Nm)');

subplot(1,2,2);
for NoGear=2:Vehicle.Gearbox.NbGears+1
    plot(Vehicle.Perfo.TabVitesse*3.6,Vehicle.Perfo.TabAccelPerGear{NoGear},Coul(NoGear-1));
    hold on;
end;
plot(Vehicle.Perfo.TabVitesse*3.6,Vehicle.Perfo.Gear,'k');
grid on;
xlabel('v (km/h)');
ylabel('accel max(m/s�)');
eval([Chaine(1:end-1) ');']);
grid on;
xlim([0 max(Vehicle.Perfo.TabVitesse)*3.6]);

figure;
subplot(1,2,1);
hold on;
for NoGear=2:Vehicle.Gearbox.NbGears+1
    plot(Vehicle.Perfo.TabWice{NoGear}*30/pi,Vehicle.Perfo.TabTrMaxPerGear{NoGear},Coul(NoGear-1));
end;
grid on;
xlabel('we (tr/mn)');
ylabel('T_{wheel max} (Nm)');
xlim([0 max(Vehicle.fc.map_spd)*30/pi]);

subplot(1,2,2);
hold on;
for NoGear=2:Vehicle.Gearbox.NbGears+1
    plot(Vehicle.Perfo.TabWice{NoGear}*30/pi,Vehicle.Perfo.TabAccelPerGear{NoGear},Coul(NoGear-1));
end;
hold on;
grid on;
xlabel('we (tr/mn)');
ylabel('accel max(m/s�)');
eval([Chaine(1:end-1) ');']);
xlim([0 max(Vehicle.fc.map_spd)*30/pi]);

