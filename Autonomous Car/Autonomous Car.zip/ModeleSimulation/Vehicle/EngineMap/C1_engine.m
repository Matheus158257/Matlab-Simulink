function fc=C1_engine
load CartoMoteurC1_dense;
fc.disp=1.0; % displacement (l)
fc.map_spd=PtAppuis.Regime*pi/30;
fc.map_trq=PtAppuis.CoupleOn;
fc.map_trq_off=PtAppuis.CoupleOff;
fc.map_throttle=PtAppuis.Papillon;
fc.fuel_map=Carto_conso_f_regime_couple_on';
fc.throttle_map_on=Carto_pap_f_regime_couple_on';


fc.torque_on_map=Carto_couple_f_regime_pap_on';
fc.torque_off_map=Carto_couple_f_regime_pap_off';

fc.min_trq=CoupleMin;
fc.max_trq=CoupleMax;
fc.cspe_map=CSPE;

fc.inertia=0.08;           % (kg*m^2), rotational inertia of the engine (unknown)
fc.fuel_den=0.749*1000; % (g/l), density of the fuel 
fc.fuel_lhv=42.6*1000; % (J/g), lower heating value of the fuel
fc.idle_consumption=0.1; % g/s fuel consumption when idling
fc.idle_speed=900*pi/30; % rd/s idle speed
fc.max_spd=max(fc.map_spd); % rd/s maximum speed

