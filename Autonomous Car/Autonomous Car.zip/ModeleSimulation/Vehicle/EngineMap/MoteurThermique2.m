% Cartographie de moteur thermique
% Points d'appuis des cartos :
%    + R�gime moteur (rd/s): fc.map_spd  
%    + Couple (Nm) : fc.map_trq
%    + Conso=f(R�gime,Couple) (gs/) : fc.fuel_map
%       => instruction Matlab pour calculer la conso � un r�gime et un
%       couple donn�:
%       debit(i)=interp2(fc.map_trq,fc.map_spd,fc.fuel_map,CoupleMoteurThermique(i),RegimeMoteur(i));
%    +  Couple maximum = f(r�gime) (Nm) : fc.max_trq
%       => instruction Matlab pour calculer la conso � un r�gime donn�
%       couplemax=interp1(fc.map_spd,fc.max_trq,regime)
% Autres donn�es :
%  Inertie kg.m� : fc.inertia 
%  Densit� de carburant g/l : fc.fuel_den
%  Pouvoir Calorifique Inf�rieur (Lower Heating Value)J/g : fc.fuel_lhv
%  Consommation de ralentis g/s : fc.idle_consumption
%  R�gime de ralenti rd/s : fc.idle_speed
%  R�gime maximumal rd/s : fc.max_spd

fc.disp=1.0; % (L) engine displacement


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% SPEED & TORQUE RANGES over which data is defined
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (rad/s), speed range of the engine
%fc.map_spd=[0,1000:500:4500]*pi/30; 
fc.map_spd=[1000:500:4500]*pi/30; 

% (N*m), torque range of the engine
fc.map_trq=[5:5:60]*1.356; 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% FUEL USE AND EMISSIONS MAPS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (g/s), fuel use map indexed vertically by fc.map_spd and 
% horizontally by fc.map_trq
fc.eff_map=[0.118	0.112	0.107	0.118	0.113	0.102	0.095	0.084
0.165	0.165	0.167	0.168	0.168	0.158	0.151	0.148
0.199	0.199	0.206	0.211	0.213	0.199	0.191	0.179
0.229	0.229	0.238	0.239	0.236	0.228	0.211	0.190
0.253	0.253	0.251	0.250	0.252	0.244	0.226	0.209
0.265	0.265	0.266	0.268	0.267	0.261	0.247	0.228
0.275	0.275	0.279	0.282	0.275	0.273	0.258	0.232
0.284	0.284	0.290	0.293	0.287	0.282	0.257	0.224
0.290	0.290	0.294	0.298	0.297	0.289	0.256	0.224
0.294	0.294	0.302	0.307	0.305	0.294	0.256	0.224
0.294	0.294	0.302	0.312	0.311	0.306	0.256	0.224
0.294	0.294	0.302	0.312	0.311	0.311	0.256	0.224];
% fuel converter efficiency map in decimal percent
fc.eff_map=fc.eff_map'; % invert map 



% convert efficiency to g/s fuel consumption
% specific calorific values in MJ/kg from Bosch handbook 3rd ed. page 232
meth_spec_cal=19.7;                                % specific calorific value for methanol, MJ/kg
gas_spec_cal=42.7;                                 % specific calorific value for gasoline, MJ/kg
M85_spec_cal=.85*meth_spec_cal+.15*gas_spec_cal;   % specific calorific value for M85, MJ/kg
M85_spec_cal=0*meth_spec_cal+1*gas_spec_cal;   % specific calorific value for M85, MJ/kg
fc.fuel_lhv= 1000*M85_spec_cal;                    % (J/g), lower heating value of the fuel 23150 J/g
[T,w]=meshgrid(fc.map_trq, fc.map_spd);
fc.map_kW=(T.*w/1000);
fc.fuel_map=(fc.map_kW./fc.eff_map)*(1000/fc.fuel_lhv);
fc.fuel_map_gpkWh=fc.fuel_map./fc.map_kW*3600;

% Rajout de la consommation � couple nul
colonne=[];
for i=1:length(fc.map_spd)
    TrancheConso=fc.fuel_map(i,:);
    colonne(i,1)=max(0.1,interp1(fc.map_trq,TrancheConso,0,'linear','extrap'));
end;
fc.fuel_map=[colonne fc.fuel_map];
fc.map_trq=[0 fc.map_trq];
% (g/s), engine out HC emissions indexed vertically by fc.map_spd and
% horizontally by fc.map_trq
fc.hc_map=zeros(size(fc.fuel_map));

% (g/s), engine out HC emissions indexed vertically by fc.map_spd and
% horizontally by fc.map_trq
fc.co_map=zeros(size(fc.fuel_map));

% (g/s), engine out HC emissions indexed vertically by fc.map_spd and
% horizontally by fc.map_trq
fc.nox_map=zeros(size(fc.fuel_map)); 

% (g/s), engine out PM emissions indexed vertically by fc.map_spd and
% horizontally by fc.map_trq
fc.pm_map=zeros(size(fc.fuel_map));

% (g/s), engine out O2 indexed vertically by fc.map_spd and
% horizontally by fc.map_trq
fc.o2_map=zeros(size(fc.fuel_map));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Cold Engine Maps
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fc.cold_tmp=20; %deg C
fc.fuel_map_cold=zeros(size(fc.fuel_map));
fc.hc_map_cold=zeros(size(fc.fuel_map));
fc.co_map_cold=zeros(size(fc.fuel_map));
fc.nox_map_cold=zeros(size(fc.fuel_map));
fc.pm_map_cold=zeros(size(fc.fuel_map));
%Process Cold Maps to generate Correction Factor Maps
names={'fc.fuel_map','fc.hc_map','fc.co_map','fc.nox_map','fc.pm_map'};
for i=1:length(names)
    %cold to hot raio, e.g. fc.fuel_map_c2h = fc.fuel_map_cold ./ fc.fuel_map
    eval([names{i},'_c2h=',names{i},'_cold./(',names{i},'+eps);'])
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% LIMITS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (N*m), max torque curve of the engine indexed by fc.map_spd
%fc.max_trq=[0 5 50 50 55 55 60 45 40]*1.356; 
fc.max_trq=[5 50 50 55 55 60 45 40]*1.356; 
fc.min_trq=fc.max_trq*0;

% (N*m), closed throttle torque of the engine (max torque that can be absorbed)
% indexed by fc.map_spd -- correlation from JDMA
fc.ct_trq=4.448/3.281*(-fc.disp)*61.02/24 * ...
   (9*(fc.map_spd/max(fc.map_spd)).^2 + 14 * (fc.map_spd/max(fc.map_spd)));

% Calcul de la consommation sp�cifique
fc.cspe_map=zeros(length(fc.map_spd),length(fc.map_trq));
for i=1:length(fc.map_spd)
    for j=1:length(fc.map_trq)
        if fc.map_spd(i)*fc.map_trq(j)~=0
            fc.cspe_map(i,j)=fc.fuel_map(i,j) *1000*3600 / (fc.map_spd(i)*fc.map_trq(j));
        else
            fc.cspe_map(i,j)=1000;
        end;
    end;
end;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DEFAULT SCALING
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (--), used to scale fc.map_spd to simulate a faster or slower running engine 
fc.spd_scale=1.0;
% (--), used to scale fc.map_trq to simulate a higher or lower torque engine
fc.trq_scale=1.0;
fc.pwr_scale=fc.spd_scale*fc.trq_scale;   % --  scale fc power

% user definable mass scaling function
fc.mass_scale_fun=inline('(x(1)*fc.trq_scale+x(2))*(x(3)*fc.spd_scale+x(4))*(fc.base_mass+fc.acc_mass)+fc.fuel_mass','x','fc.spd_scale','fc.trq_scale','fc.base_mass','fc.acc_mass','fc.fuel_mass');
fc.mass_scale_coef=[1 0 1 0]; % coefficients of mass scaling function


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% STUFF THAT SCALES WITH TRQ & SPD SCALES (MASS AND INERTIA)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fc.inertia=0.1*fc.pwr_scale;           % (kg*m^2), rotational inertia of the engine (unknown)
fc.max_pwr=(max(fc.map_spd.*fc.max_trq)/1000)*fc.pwr_scale; % kW     peak engine power

fc.base_mass=1.38*1.8*fc.max_pwr;            % (kg), mass of the engine block and head (base engine)
                                        %       mass penalty of 1.8 kg/kW from 1994 OTA report, Table 3 
fc.acc_mass=1.38*0.8*fc.max_pwr;             % kg    engine accy's, electrics, cntrl's - assumes mass penalty of 0.8 kg/kW (from OTA report)
fc.fuel_mass=1.38*0.6*fc.max_pwr;            % kg    mass of fuel and fuel tank (from OTA report)
fc.mass=fc.base_mass+fc.acc_mass; % kg  total engine/fuel system mass
% estimated assuming a specific energy of 0.285 kW/kg (including exhaust and
% other accessories) and a 0.726 ratio of M85 max power to gasoline max power
%fc.mass=max(fc.map_spd.*fc.max_trq)/(0.726*0.285*1000); % (kg)
fc.ext_sarea=0.3*(fc.max_pwr/100)^0.67;       % m^2    exterior surface area of engine


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OTHER DATA
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fc.inertia=0.1;           % (kg*m^2), rotational inertia of the engine (unknown)
fc.fuel_den=0.749*1000; % (g/l), density of the fuel 
fc.fuel_lhv=42.6*1000; % (J/g), lower heating value of the fuel
fc.idle_consumption=0.1; % g/s fuel consumption when idling
fc.idle_speed=fc.map_spd(1); % rd/s idle speed
fc.max_spd=max(fc.map_spd); % rd/s maximum speed
CoupleMaxEmbrayage=max(fc.max_trq); % Couple maximal pouvant �tre transmis par l'embrayage en phase de glissement

AddLog(hLog,sprintf('Chargement du moteur thermique. Puissance max : %i kW\n',round(fc.max_pwr)));

ListeVarAGarder={'fc.idle_consumption','fc.fuel_den','fc.fuel_lhv','fc.fuel_map','fc.fuel_consumption','fc.idle_speed','fc.inertia','fc.cspe_map','fc.map_spd','fc.map_trq','fc.mass','fc.max_pwr','fc.max_spd','fc.max_trq','fc.min_trq'};
C=whos('fc*');
for i=1:length(C)
    trouve=0;
    for j=1:length(ListeVarAGarder)
        if strcmpi(ListeVarAGarder{j},C(i).name)
            trouve=1;
        end;
    end; % Fin du for j=1:length(ListeVarAGarder)
    if trouve==0
        clear(C(i).name);
    end;
end; % Fin du for i=1:length(C)
