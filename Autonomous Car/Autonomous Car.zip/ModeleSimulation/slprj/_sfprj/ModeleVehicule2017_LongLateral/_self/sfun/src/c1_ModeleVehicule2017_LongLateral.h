#ifndef __c1_ModeleVehicule2017_LongLateral_h__
#define __c1_ModeleVehicule2017_LongLateral_h__

/* Include files */
#include "sf_runtime/sfc_sf.h"
#include "sf_runtime/sfc_mex.h"
#include "rtwtypes.h"
#include "multiword_types.h"

/* Type Definitions */
#ifndef typedef_SFc1_ModeleVehicule2017_LongLateralInstanceStruct
#define typedef_SFc1_ModeleVehicule2017_LongLateralInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint32_T chartNumber;
  uint32_T instanceNumber;
  uint8_T c1_doSetSimStateSideEffects;
  const mxArray *c1_setSimStateSideEffectsInfo;
  void *c1_fEmlrtCtx;
  int32_T *c1_sfEvent;
  uint8_T *c1_is_active_c1_ModeleVehicule2017_LongLateral;
  uint8_T *c1_is_c1_ModeleVehicule2017_LongLateral;
  real_T *c1_Rapport;
  real_T *c1_RegimeMoteur;
  real_T *c1_StartTimer;
  real_T *c1_GearOk;
  real_T *c1_Timer;
  real_T *c1_ProchainRapport;
  real_T *c1_DureeChangement;
  real_T *c1_RapportInit;
  real_T *c1_ResetSignal;
} SFc1_ModeleVehicule2017_LongLateralInstanceStruct;

#endif                                 /*typedef_SFc1_ModeleVehicule2017_LongLateralInstanceStruct*/

/* Named Constants */

/* Variable Declarations */
extern struct SfDebugInstanceStruct *sfGlobalDebugInstanceStruct;

/* Variable Definitions */

/* Function Declarations */
extern const mxArray
  *sf_c1_ModeleVehicule2017_LongLateral_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c1_ModeleVehicule2017_LongLateral_get_check_sum(mxArray *plhs[]);
extern void c1_ModeleVehicule2017_LongLateral_method_dispatcher(SimStruct *S,
  int_T method, void *data);

#endif
